from .slider import MDSlider  # NOQA F401
